
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef enum {
    CARGO_TAKEOFF   = 0,
    TAKEOFF         = 1,
    LANDING         = 2,
    EMERGENCY       = 3
} FlightType;

static const char *ftype_name[] = {
    "CargoTakeoff", "Takeoff", "Landing", "EMERGENCY"
};

#define NUM_RUNWAYS      3
#define WAIT_THRESHOLD   8
#define SIM_FLIGHTS     25

typedef struct {
    int       id;
    FlightType type;
    int       priority;
    time_t    arrival;
    int       fuel_low;
} Flight;

#define PQ_CAPACITY 256
static Flight  pq_data[PQ_CAPACITY];
static int     pq_size = 0;
static pthread_mutex_t pq_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pq_cond  = PTHREAD_COND_INITIALIZER;

static void pq_swap(int a, int b) {
    Flight tmp = pq_data[a]; pq_data[a] = pq_data[b]; pq_data[b] = tmp;
}

static void pq_push(Flight f) {

    if (pq_size >= PQ_CAPACITY) return;
    pq_data[pq_size] = f;
    int i = pq_size++;
    while (i > 0) {
        int parent = (i - 1) / 2;
        if (pq_data[parent].priority < pq_data[i].priority) {
            pq_swap(parent, i); i = parent;
        } else break;
    }
}

static Flight pq_pop(void) {

    Flight top = pq_data[0];
    pq_data[0] = pq_data[--pq_size];
    int i = 0;
    while (1) {
        int l = 2*i+1, r = 2*i+2, largest = i;
        if (l < pq_size && pq_data[l].priority > pq_data[largest].priority) largest = l;
        if (r < pq_size && pq_data[r].priority > pq_data[largest].priority) largest = r;
        if (largest == i) break;
        pq_swap(i, largest); i = largest;
    }
    return top;
}

typedef struct {
    int     busy;
    int     current_flight_id;
    int     under_maintenance;
    pthread_mutex_t mutex;
} Runway;

static Runway runways[NUM_RUNWAYS];

static int      emergency_pending = 0;
static int      emergency_flight_id = -1;
static pthread_cond_t  emergency_cond = PTHREAD_COND_INITIALIZER;

static int simulation_running = 1;
static int flights_generated  = 0;
static int flights_completed  = 0;
static pthread_mutex_t done_mutex = PTHREAD_MUTEX_INITIALIZER;

static void *flight_generator(void *arg) {
    (void)arg;
    srand((unsigned)time(NULL));
    int weights[]      = { 4, 3, 2, 1 };

    for (int i = 0; i < SIM_FLIGHTS && simulation_running; i++) {
        Flight f;
        f.id       = i + 1;
        f.arrival  = time(NULL);
        f.fuel_low = (rand() % 10 == 0);

        int roll = rand() % 10, acc = 0; f.type = LANDING;
        for (int t = 0; t < 4; t++) {
            acc += weights[t];
            if (roll < acc) { f.type = (FlightType)t; break; }
        }

        if (f.type == EMERGENCY)             f.priority = 100;
        else if (f.type == LANDING && f.fuel_low) f.priority = 90;
        else if (f.type == LANDING)          f.priority = 60;
        else if (f.type == TAKEOFF)          f.priority = 40;
        else                                 f.priority = 20;

        pthread_mutex_lock(&pq_mutex);
        pq_push(f);
        flights_generated++;
        printf("[GEN] Flight #%d (%s, priority=%d, fuel_low=%d)\n",
               f.id, ftype_name[f.type], f.priority, f.fuel_low);

        if (f.type == EMERGENCY || (f.type == LANDING && f.fuel_low)) {
            emergency_pending   = 1;
            emergency_flight_id = f.id;
            pthread_cond_broadcast(&emergency_cond);
        }

        pthread_cond_broadcast(&pq_cond);
        pthread_mutex_unlock(&pq_mutex);

        sleep(1 + rand() % 2);
    }

    pthread_mutex_lock(&pq_mutex);
    simulation_running = 0;
    pthread_cond_broadcast(&pq_cond);
    pthread_cond_broadcast(&emergency_cond);
    pthread_mutex_unlock(&pq_mutex);
    return NULL;
}

typedef struct { int runway_id; } RunwayArg;

static void *runway_controller(void *arg) {
    RunwayArg *ra = (RunwayArg *)arg;
    int rid = ra->runway_id;

    while (1) {
        pthread_mutex_lock(&pq_mutex);

        while (simulation_running && pq_size == 0)
            pthread_cond_wait(&pq_cond, &pq_mutex);

        if (!simulation_running && pq_size == 0) {
            pthread_mutex_unlock(&pq_mutex);
            break;
        }

        pthread_mutex_lock(&runways[rid].mutex);
        if (runways[rid].busy || runways[rid].under_maintenance) {
            pthread_mutex_unlock(&runways[rid].mutex);
            pthread_mutex_unlock(&pq_mutex);
            sleep(1);
            continue;
        }

        Flight f = pq_pop();
        runways[rid].busy = 1;
        runways[rid].current_flight_id = f.id;
        pthread_mutex_unlock(&runways[rid].mutex);
        pthread_mutex_unlock(&pq_mutex);

        int duration = (f.type == EMERGENCY) ? 1 :
                       (f.type == LANDING)   ? 2 :
                       (f.type == TAKEOFF)   ? 2 : 3;

        printf("  [RWY-%d] BEGIN Flight #%d (%s, p=%d) — %ds\n",
               rid, f.id, ftype_name[f.type], f.priority, duration);
        sleep(duration);
        printf("  [RWY-%d] DONE  Flight #%d\n", rid, f.id);

        pthread_mutex_lock(&runways[rid].mutex);
        runways[rid].busy = 0;
        runways[rid].current_flight_id = -1;
        pthread_mutex_unlock(&runways[rid].mutex);

        if (rand() % 20 == 0) {
            pthread_mutex_lock(&runways[rid].mutex);
            runways[rid].under_maintenance = 1;
            pthread_mutex_unlock(&runways[rid].mutex);
            printf("  [RWY-%d] MAINTENANCE (3s)\n", rid);
            sleep(3);
            pthread_mutex_lock(&runways[rid].mutex);
            runways[rid].under_maintenance = 0;
            pthread_mutex_unlock(&runways[rid].mutex);
        }

        pthread_mutex_lock(&done_mutex);
        flights_completed++;
        pthread_mutex_unlock(&done_mutex);
    }
    return NULL;
}

static void *emergency_monitor(void *arg) {
    (void)arg;

    while (simulation_running) {
        pthread_mutex_lock(&pq_mutex);
        while (simulation_running && !emergency_pending)
            pthread_cond_wait(&emergency_cond, &pq_mutex);

        if (!simulation_running) {
            pthread_mutex_unlock(&pq_mutex);
            break;
        }

        printf("  [EMERGENCY MONITOR] Emergency detected! Flight #%d — preempting runways\n",
               emergency_flight_id);

        pthread_cond_broadcast(&pq_cond);
        emergency_pending   = 0;
        emergency_flight_id = -1;
        pthread_mutex_unlock(&pq_mutex);
    }
    return NULL;
}

static void *priority_adjuster(void *arg) {
    (void)arg;
    while (simulation_running) {
        sleep(WAIT_THRESHOLD);
        time_t now = time(NULL);
        pthread_mutex_lock(&pq_mutex);
        for (int i = 0; i < pq_size; i++) {
            double waited = difftime(now, pq_data[i].arrival);
            if (waited > WAIT_THRESHOLD) {
                pq_data[i].priority++;
                printf("  [PRIORITY] Flight #%d waited %.0fs → priority now %d\n",
                       pq_data[i].id, waited, pq_data[i].priority);
            }
        }

        for (int i = pq_size/2 - 1; i >= 0; i--) {
            int cur = i;
            while (1) {
                int l = 2*cur+1, r = 2*cur+2, lg = cur;
                if (l < pq_size && pq_data[l].priority > pq_data[lg].priority) lg = l;
                if (r < pq_size && pq_data[r].priority > pq_data[lg].priority) lg = r;
                if (lg == cur) break;
                pq_swap(cur, lg); cur = lg;
            }
        }
        pthread_mutex_unlock(&pq_mutex);
    }
    return NULL;
}

int main(void) {
    printf("=== Airport Runway Control System ===\n");
    printf("Runways: %d | Flights: %d | Wait Threshold: %ds\n\n",
           NUM_RUNWAYS, SIM_FLIGHTS, WAIT_THRESHOLD);

    for (int r = 0; r < NUM_RUNWAYS; r++) {
        runways[r].busy = 0;
        runways[r].current_flight_id = -1;
        runways[r].under_maintenance = 0;
        pthread_mutex_init(&runways[r].mutex, NULL);
    }

    pthread_t gen_thread, emerg_thread, adj_thread;
    pthread_t ctrl_threads[NUM_RUNWAYS];
    RunwayArg ctrl_args[NUM_RUNWAYS];

    pthread_create(&emerg_thread, NULL, emergency_monitor, NULL);
    pthread_create(&adj_thread,   NULL, priority_adjuster,  NULL);

    for (int r = 0; r < NUM_RUNWAYS; r++) {
        ctrl_args[r].runway_id = r;
        pthread_create(&ctrl_threads[r], NULL, runway_controller, &ctrl_args[r]);
    }

    pthread_create(&gen_thread, NULL, flight_generator, NULL);

    pthread_join(gen_thread, NULL);
    for (int r = 0; r < NUM_RUNWAYS; r++) pthread_join(ctrl_threads[r], NULL);
    pthread_join(emerg_thread, NULL);
    pthread_join(adj_thread,   NULL);

    printf("\n=== Simulation Complete ===\n");
    printf("Generated: %d | Completed: %d\n", flights_generated, flights_completed);

    pthread_mutex_destroy(&pq_mutex);
    pthread_cond_destroy(&pq_cond);
    pthread_cond_destroy(&emergency_cond);
    pthread_mutex_destroy(&done_mutex);
    for (int r = 0; r < NUM_RUNWAYS; r++)
        pthread_mutex_destroy(&runways[r].mutex);

    return 0;
}
