
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <time.h>
#include <stdint.h>

#define N            1000
#define M            4
#define TILE_SIZE    100
#define NUM_TILES    (N / TILE_SIZE) * (N / TILE_SIZE)
#define T_HOT        35.0
#define T_COLD      -10.0
#define MANHATTAN    2
#define NAN_SENTINEL (NAN)
#define MAX_THREADS  16

static double global_matrix[N][N];
static int    overlap_count[N][N];

static double (*sat_matrix[M])[N];

static double g_max, g_min, g_mean, g_variance;
static int    g_hotspot_count, g_coldspot_count, g_anomaly_count;

typedef struct { int r, c; double val; } Cell;

#define MAX_SPOTS 50000
static Cell hotspots[MAX_SPOTS];
static Cell coldspots[MAX_SPOTS];
static int  n_hot = 0, n_cold = 0;

typedef struct { int r, c; double score; } RiskCell;
static RiskCell top10[10];

static pthread_mutex_t merge_mutex   = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t stats_mutex   = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t hotspot_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t cold_mutex    = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t risk_mutex    = PTHREAD_MUTEX_INITIALIZER;

static pthread_mutex_t  ab_mutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t   ab_cond   = PTHREAD_COND_INITIALIZER;
static int              ab_done   = 0;

static double norm_matrix[N][N];
static double g_norm_min, g_norm_max;

static int     tile_queue[NUM_TILES];
static int     queue_head = 0;
static int     queue_tail = 0;
static pthread_mutex_t  queue_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t   queue_cond  = PTHREAD_COND_INITIALIZER;
static int     tiles_remaining = NUM_TILES;

typedef struct { int sat_id; } SatArg;

static void interpolate(double mat[][N], int rows, int cols) {

    int changed = 1;
    while (changed) {
        changed = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (!isnan(mat[i][j])) continue;
                double sum = 0.0; int cnt = 0;
                if (i > 0       && !isnan(mat[i-1][j])) { sum += mat[i-1][j]; cnt++; }
                if (i < rows-1  && !isnan(mat[i+1][j])) { sum += mat[i+1][j]; cnt++; }
                if (j > 0       && !isnan(mat[i][j-1])) { sum += mat[i][j-1]; cnt++; }
                if (j < cols-1  && !isnan(mat[i][j+1])) { sum += mat[i][j+1]; cnt++; }
                if (cnt > 0) { mat[i][j] = sum / cnt; changed = 1; }
            }
        }
    }
}

static void *satellite_thread(void *arg) {
    SatArg *sa = (SatArg *)arg;
    int id = sa->sat_id;

    interpolate(sat_matrix[id], N, N);

    pthread_mutex_lock(&merge_mutex);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (isnan(sat_matrix[id][i][j])) continue;
            global_matrix[i][j] += sat_matrix[id][i][j];
            overlap_count[i][j]++;
        }
    }
    pthread_mutex_unlock(&merge_mutex);

    return NULL;
}

static void finalize_merge(void) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            if (overlap_count[i][j] > 1)
                global_matrix[i][j] /= overlap_count[i][j];
}

typedef struct {

    double local_max, local_min, local_sum, local_sum_sq;
    long   local_count;
    int    local_anomaly;
} TileResult;

static TileResult tile_results[NUM_TILES];

static void *tile_worker(void *arg) {
    (void)arg;

    while (1) {

        pthread_mutex_lock(&queue_mutex);
        while (queue_head == queue_tail && tiles_remaining > 0)
            pthread_cond_wait(&queue_cond, &queue_mutex);

        if (tiles_remaining == 0 && queue_head == queue_tail) {
            pthread_mutex_unlock(&queue_mutex);
            break;
        }

        int tile_idx = tile_queue[queue_head % NUM_TILES];
        queue_head++;
        pthread_mutex_unlock(&queue_mutex);

        int tiles_per_row = N / TILE_SIZE;
        int tr = tile_idx / tiles_per_row;
        int tc = tile_idx % tiles_per_row;
        int r0 = tr * TILE_SIZE, c0 = tc * TILE_SIZE;

        TileResult *res = &tile_results[tile_idx];
        res->local_max   = -DBL_MAX;
        res->local_min   =  DBL_MAX;
        res->local_sum   = 0.0;
        res->local_sum_sq = 0.0;
        res->local_count  = 0;
        res->local_anomaly = 0;

        for (int i = r0; i < r0 + TILE_SIZE; i++) {
            for (int j = c0; j < c0 + TILE_SIZE; j++) {
                double v = global_matrix[i][j];
                if (v > res->local_max) res->local_max = v;
                if (v < res->local_min) res->local_min = v;
                res->local_sum += v;
                res->local_count++;
            }
        }
        double local_mean = res->local_sum / res->local_count;

        double sq_sum = 0.0;
        for (int i = r0; i < r0 + TILE_SIZE; i++) {
            for (int j = c0; j < c0 + TILE_SIZE; j++) {
                double diff = global_matrix[i][j] - local_mean;
                sq_sum += diff * diff;
            }
        }
        double variance = sq_sum / res->local_count;
        double std_dev  = sqrt(variance);
        res->local_sum_sq = sq_sum;

        for (int i = r0; i < r0 + TILE_SIZE; i++) {
            for (int j = c0; j < c0 + TILE_SIZE; j++) {
                if (fabs(global_matrix[i][j] - local_mean) > 2.0 * std_dev)
                    res->local_anomaly++;
            }
        }

        pthread_mutex_lock(&stats_mutex);
        if (res->local_max > g_max) g_max = res->local_max;
        if (res->local_min < g_min) g_min = res->local_min;
        g_mean     += res->local_sum;
        g_variance += res->local_sum_sq;
        g_anomaly_count += res->local_anomaly;
        pthread_mutex_unlock(&stats_mutex);

        pthread_mutex_lock(&queue_mutex);
        tiles_remaining--;
        if (tiles_remaining == 0)
            pthread_cond_broadcast(&queue_cond);
        pthread_mutex_unlock(&queue_mutex);
    }
    return NULL;
}

static void run_tile_phase(void) {

    for (int i = 0; i < NUM_TILES; i++) {
        tile_queue[i] = i;
        queue_tail++;
    }

    g_max = -DBL_MAX; g_min = DBL_MAX;

    pthread_t workers[MAX_THREADS];
    pthread_mutex_lock(&queue_mutex);
    pthread_cond_broadcast(&queue_cond);
    pthread_mutex_unlock(&queue_mutex);

    for (int t = 0; t < MAX_THREADS; t++)
        pthread_create(&workers[t], NULL, tile_worker, NULL);

    for (int t = 0; t < MAX_THREADS; t++)
        pthread_join(workers[t], NULL);

    long total = (long)N * N;
    g_mean    /= total;
    g_variance = g_variance / total - g_mean * g_mean;

    g_norm_min = g_min;
    g_norm_max = g_max;
}

static void *task_A(void *arg) {
    (void)arg;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (global_matrix[i][j] > T_HOT) {
                pthread_mutex_lock(&hotspot_mutex);
                if (n_hot < MAX_SPOTS) {
                    hotspots[n_hot].r   = i;
                    hotspots[n_hot].c   = j;
                    hotspots[n_hot].val = global_matrix[i][j];
                    n_hot++;
                }
                g_hotspot_count++;
                pthread_mutex_unlock(&hotspot_mutex);
            }
        }
    }

    pthread_mutex_lock(&ab_mutex);
    ab_done |= 1;
    pthread_cond_broadcast(&ab_cond);
    pthread_mutex_unlock(&ab_mutex);
    return NULL;
}

static void *task_B(void *arg) {
    (void)arg;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (global_matrix[i][j] < T_COLD) {
                pthread_mutex_lock(&cold_mutex);
                if (n_cold < MAX_SPOTS) {
                    coldspots[n_cold].r   = i;
                    coldspots[n_cold].c   = j;
                    coldspots[n_cold].val = global_matrix[i][j];
                    n_cold++;
                }
                g_coldspot_count++;
                pthread_mutex_unlock(&cold_mutex);
            }
        }
    }

    pthread_mutex_lock(&ab_mutex);
    ab_done |= 2;
    pthread_cond_broadcast(&ab_cond);
    pthread_mutex_unlock(&ab_mutex);
    return NULL;
}

static void *task_C(void *arg) {
    (void)arg;
    double range = g_norm_max - g_norm_min;
    if (range == 0.0) range = 1.0;

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            double norm = (global_matrix[i][j] - g_norm_min) / range;

            int near_hot  = 0, near_cold = 0;

            pthread_mutex_lock(&hotspot_mutex);
            for (int h = 0; h < n_hot && !near_hot; h++) {
                int dr = abs(hotspots[h].r - i);
                int dc = abs(hotspots[h].c - j);
                if (dr + dc <= MANHATTAN) near_hot = 1;
            }
            pthread_mutex_unlock(&hotspot_mutex);

            pthread_mutex_lock(&cold_mutex);
            for (int c = 0; c < n_cold && !near_cold; c++) {
                int dr = abs(coldspots[c].r - i);
                int dc = abs(coldspots[c].c - j);
                if (dr + dc <= MANHATTAN) near_cold = 1;
            }
            pthread_mutex_unlock(&cold_mutex);

            if (near_hot && near_cold)
                norm = norm * 0.7 + 0.15;

            norm_matrix[i][j] = norm;
        }
    }
    return NULL;
}

static double proximity_to_hotspots(int r, int c) {
    double best = 0.0;
    for (int h = 0; h < n_hot; h++) {
        int dist = abs(hotspots[h].r - r) + abs(hotspots[h].c - c);
        double score = 1.0 / (dist + 1);
        if (score > best) best = score;
    }
    return best;
}

static double proximity_to_coldspots(int r, int c) {
    double best = 0.0;
    for (int h = 0; h < n_cold; h++) {
        int dist = abs(coldspots[h].r - r) + abs(coldspots[h].c - c);
        double score = 1.0 / (dist + 1);
        if (score > best) best = score;
    }
    return best;
}

static void *task_risk(void *arg) {
    (void)arg;

    pthread_mutex_lock(&ab_mutex);
    while (ab_done != 3)
        pthread_cond_wait(&ab_cond, &ab_mutex);
    pthread_mutex_unlock(&ab_mutex);

    double best_scores[10] = {0};
    int    best_r[10] = {0}, best_c[10] = {0};

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            double ph = proximity_to_hotspots(i, j);
            double pc = proximity_to_coldspots(i, j);
            double risk = norm_matrix[i][j] * ph / (pc + 1.0);

            int min_idx = 0;
            for (int k = 1; k < 10; k++)
                if (best_scores[k] < best_scores[min_idx]) min_idx = k;
            if (risk > best_scores[min_idx]) {
                best_scores[min_idx] = risk;
                best_r[min_idx] = i;
                best_c[min_idx] = j;
            }
        }
    }

    pthread_mutex_lock(&risk_mutex);
    for (int k = 0; k < 10; k++) {
        top10[k].r     = best_r[k];
        top10[k].c     = best_c[k];
        top10[k].score = best_scores[k];
    }
    pthread_mutex_unlock(&risk_mutex);
    return NULL;
}

static void generate_satellite_data(void) {
    srand(42);
    for (int s = 0; s < M; s++) {
        sat_matrix[s] = malloc(sizeof(*sat_matrix[s]) * N);
        if (!sat_matrix[s]) { perror("malloc"); exit(1); }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {

                if (rand() % 10 == 0) {
                    sat_matrix[s][i][j] = NAN;
                } else {
                    sat_matrix[s][i][j] = -30.0 + (rand() % 8001) / 100.0;
                }
            }
        }

        for (int k = 0; k < 50; k++) {
            int r = rand() % N, c = rand() % N;
            sat_matrix[s][r][c] = 36.0 + (rand() % 1000) / 100.0;
        }
        for (int k = 0; k < 30; k++) {
            int r = rand() % N, c = rand() % N;
            sat_matrix[s][r][c] = -15.0 - (rand() % 500) / 100.0;
        }
    }
}

int main(void) {
    printf("=== Climate Anomaly Analysis System ===\n");
    printf("Matrix: %dx%d | Satellites: %d | Tile: %dx%d | Threads: %d\n\n",
           N, N, M, TILE_SIZE, TILE_SIZE, MAX_THREADS);

    memset(global_matrix,  0, sizeof(global_matrix));
    memset(overlap_count,  0, sizeof(overlap_count));

    printf("[Phase 0] Generating satellite data...\n");
    generate_satellite_data();

    pthread_t sat_threads[M];
    SatArg    sat_args[M];
    for (int s = 0; s < M; s++) {
        sat_args[s].sat_id = s;
        pthread_create(&sat_threads[s], NULL, satellite_thread, &sat_args[s]);
    }
    for (int s = 0; s < M; s++)
        pthread_join(sat_threads[s], NULL);

    finalize_merge();
    printf("[Phase 0] Satellite merge complete.\n\n");

    printf("[Phase 1] Processing %d tiles with %d worker threads (dynamic load balancing)...\n",
           NUM_TILES, MAX_THREADS);
    run_tile_phase();
    printf("[Phase 1] Tile processing complete.\n\n");

    printf("--- Global Statistics ---\n");
    printf("  Max      : %.2f°C\n", g_max);
    printf("  Min      : %.2f°C\n", g_min);
    printf("  Mean     : %.4f°C\n", g_mean);
    printf("  Variance : %.4f\n",   g_variance);
    printf("  Anomalies: %d cells\n\n", g_anomaly_count);

    printf("[Phase 2] Running concurrent Task A (hotspots), B (coldspots), C (normalization)...\n");
    pthread_t tA, tB, tC;
    pthread_create(&tA, NULL, task_A, NULL);
    pthread_create(&tB, NULL, task_B, NULL);
    pthread_create(&tC, NULL, task_C, NULL);
    pthread_join(tA, NULL);
    pthread_join(tB, NULL);
    pthread_join(tC, NULL);
    printf("[Phase 2] Task A/B/C complete.\n\n");

    printf("  Hotspots (>%.1f°C) : %d\n", T_HOT,  g_hotspot_count);
    printf("  Coldspots (<%.1f°C): %d\n", T_COLD, g_coldspot_count);

    printf("\n[Phase 3] Computing risk scores...\n");
    pthread_t tRisk;
    pthread_create(&tRisk, NULL, task_risk, NULL);
    pthread_join(tRisk, NULL);

    printf("\n--- Sample Normalized Sub-Matrix (5x5 from [0,0]) ---\n");
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++)
            printf("  %.4f", norm_matrix[i][j]);
        printf("\n");
    }

    printf("\n--- Top 10 Risk Cells (Extreme Weather Prediction) ---\n");
    printf("  %-6s %-6s %-12s\n", "Row", "Col", "Risk Score");
    for (int k = 0; k < 10; k++)
        printf("  %-6d %-6d %-12.6f\n", top10[k].r, top10[k].c, top10[k].score);

    for (int s = 0; s < M; s++) free(sat_matrix[s]);
    pthread_mutex_destroy(&merge_mutex);
    pthread_mutex_destroy(&stats_mutex);
    pthread_mutex_destroy(&hotspot_mutex);
    pthread_mutex_destroy(&cold_mutex);
    pthread_mutex_destroy(&risk_mutex);
    pthread_mutex_destroy(&queue_mutex);
    pthread_mutex_destroy(&ab_mutex);
    pthread_cond_destroy(&queue_cond);
    pthread_cond_destroy(&ab_cond);

    printf("\n[Done]\n");
    return 0;
}
