
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef enum { NORMAL = 0, SERIOUS = 1, CRITICAL = 2 } PatientType;

static const char *type_name[] = { "Normal", "Serious", "Critical" };

typedef struct Patient {
    int          id;
    PatientType  type;
    time_t       arrival;
    struct Patient *next;
} Patient;

static Patient *queue[3];
static int      queue_len[3];

static pthread_mutex_t queue_mutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t stats_mutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  patient_cv   = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  senior_cv    = PTHREAD_COND_INITIALIZER;

#define NUM_SENIOR 2
#define NUM_JUNIOR 2

static int senior_consec_normal[NUM_SENIOR];
static int junior_consec_normal[NUM_JUNIOR];

static int simulation_running = 1;
static int patient_id_counter = 0;
static int total_treated       = 0;

static void enqueue(Patient *p) {
    p->next = NULL;
    PatientType t = p->type;
    if (!queue[t]) {
        queue[t] = p;
    } else {
        Patient *tail = queue[t];
        while (tail->next) tail = tail->next;
        tail->next = p;
    }
    queue_len[t]++;
}

static Patient *dequeue(PatientType t) {
    if (!queue[t]) return NULL;
    Patient *p = queue[t];
    queue[t] = p->next;
    queue_len[t]--;
    return p;
}

static void treat(const char *doctor_name, Patient *p) {
    printf("  [%s] Treating %s patient #%d\n",
           doctor_name, type_name[p->type], p->id);

    int secs = (p->type == CRITICAL) ? 3 : (p->type == SERIOUS) ? 2 : 1;
    sleep(secs);
    printf("  [%s] Done with patient #%d\n", doctor_name, p->id);
    pthread_mutex_lock(&stats_mutex);
    total_treated++;
    pthread_mutex_unlock(&stats_mutex);
    free(p);
}

static void *timeout_monitor(void *arg) {
    (void)arg;
    while (simulation_running) {
        sleep(5);
        time_t now = time(NULL);
        pthread_mutex_lock(&queue_mutex);
        for (int t = 0; t < 3; t++) {
            Patient *p = queue[t];
            while (p) {
                if (difftime(now, p->arrival) > 30.0) {

                    if (p->type < CRITICAL) {
                        printf("  [TIMEOUT] Patient #%d waited >30s, promoting from %s\n",
                               p->id, type_name[p->type]);
                        p->type++;
                    }
                    pthread_cond_broadcast(&patient_cv);
                    pthread_cond_broadcast(&senior_cv);
                }
                p = p->next;
            }
        }
        pthread_mutex_unlock(&queue_mutex);
    }
    return NULL;
}

static void *promotion_monitor(void *arg) {
    (void)arg;
    while (simulation_running) {
        sleep(2);
        pthread_mutex_lock(&queue_mutex);
        if (queue_len[SERIOUS] >= 5) {
            Patient *p = dequeue(SERIOUS);
            if (p) {
                printf("  [PROMO] 5 serious waiting — promoting patient #%d to Critical\n",
                       p->id);
                p->type = CRITICAL;
                enqueue(p);
                pthread_cond_broadcast(&senior_cv);
                pthread_cond_broadcast(&patient_cv);
            }
        }
        pthread_mutex_unlock(&queue_mutex);
    }
    return NULL;
}

static void *patient_generator(void *arg) {
    (void)arg;
    PatientType types[] = { NORMAL, NORMAL, NORMAL, SERIOUS, SERIOUS, CRITICAL };
    int ntypes = 6;
    srand((unsigned)time(NULL));

    for (int i = 0; i < 20 && simulation_running; i++) {
        Patient *p = malloc(sizeof(Patient));
        p->id      = ++patient_id_counter;
        p->type    = types[rand() % ntypes];
        p->arrival = time(NULL);
        p->next    = NULL;

        pthread_mutex_lock(&queue_mutex);
        enqueue(p);
        printf("[ARRIVE] Patient #%d (%s)\n", p->id, type_name[p->type]);
        pthread_cond_broadcast(&patient_cv);
        if (p->type == CRITICAL)
            pthread_cond_broadcast(&senior_cv);
        pthread_mutex_unlock(&queue_mutex);

        sleep(1 + rand() % 2);
    }

    sleep(15);
    simulation_running = 0;
    pthread_cond_broadcast(&patient_cv);
    pthread_cond_broadcast(&senior_cv);
    return NULL;
}

typedef struct { int id; } DoctorArg;

static void *senior_doctor(void *arg) {
    DoctorArg *da = (DoctorArg *)arg;
    int id = da->id;
    char name[32];
    snprintf(name, sizeof(name), "Senior-%d", id);

    while (1) {
        pthread_mutex_lock(&queue_mutex);

        while (simulation_running &&
               queue_len[CRITICAL] == 0 &&
               queue_len[SERIOUS]  == 0 &&
               queue_len[NORMAL]   == 0)
            pthread_cond_wait(&patient_cv, &queue_mutex);

        if (!simulation_running &&
            queue_len[CRITICAL] == 0 &&
            queue_len[SERIOUS]  == 0 &&
            queue_len[NORMAL]   == 0) {
            pthread_mutex_unlock(&queue_mutex);
            break;
        }

        Patient *p = NULL;

        pthread_mutex_lock(&stats_mutex);
        int force_serious = (senior_consec_normal[id] >= 3 && queue_len[SERIOUS] > 0);
        pthread_mutex_unlock(&stats_mutex);

        if (!force_serious && queue_len[CRITICAL] > 0)
            p = dequeue(CRITICAL);
        else if (force_serious || queue_len[SERIOUS] > 0)
            p = dequeue(SERIOUS);
        else if (queue_len[NORMAL] > 0)
            p = dequeue(NORMAL);

        pthread_mutex_unlock(&queue_mutex);

        if (!p) continue;

        pthread_mutex_lock(&stats_mutex);
        if (p->type == NORMAL) senior_consec_normal[id]++;
        else                   senior_consec_normal[id] = 0;
        pthread_mutex_unlock(&stats_mutex);

        treat(name, p);
    }
    return NULL;
}

static void *junior_doctor(void *arg) {
    DoctorArg *da = (DoctorArg *)arg;
    int id = da->id;
    char name[32];
    snprintf(name, sizeof(name), "Junior-%d", id);

    while (1) {
        pthread_mutex_lock(&queue_mutex);

        while (simulation_running &&
               queue_len[SERIOUS] == 0 &&
               queue_len[NORMAL]  == 0)
            pthread_cond_wait(&patient_cv, &queue_mutex);

        if (!simulation_running &&
            queue_len[SERIOUS] == 0 &&
            queue_len[NORMAL]  == 0) {
            pthread_mutex_unlock(&queue_mutex);
            break;
        }

        Patient *p = NULL;

        pthread_mutex_lock(&stats_mutex);
        int force_serious = (junior_consec_normal[id] >= 3 && queue_len[SERIOUS] > 0);
        pthread_mutex_unlock(&stats_mutex);

        if (force_serious || queue_len[SERIOUS] > 0)
            p = dequeue(SERIOUS);
        else if (queue_len[NORMAL] > 0)
            p = dequeue(NORMAL);

        pthread_mutex_unlock(&queue_mutex);

        if (!p) continue;

        pthread_mutex_lock(&stats_mutex);
        if (p->type == NORMAL) junior_consec_normal[id]++;
        else                   junior_consec_normal[id] = 0;
        pthread_mutex_unlock(&stats_mutex);

        treat(name, p);
    }
    return NULL;
}

int main(void) {
    printf("=== Smart Hospital Emergency Department ===\n");
    printf("Doctors: %d Senior, %d Junior | Rules: Critical-first, 30s timeout, "
           "Promo@5serious, Force-serious@3normal\n\n",
           NUM_SENIOR, NUM_JUNIOR);

    pthread_t gen_thread, promo_thread, timeout_thread;
    pthread_t senior_threads[NUM_SENIOR], junior_threads[NUM_JUNIOR];
    DoctorArg senior_args[NUM_SENIOR], junior_args[NUM_JUNIOR];

    pthread_create(&promo_thread,   NULL, promotion_monitor, NULL);
    pthread_create(&timeout_thread, NULL, timeout_monitor,   NULL);

    for (int i = 0; i < NUM_SENIOR; i++) {
        senior_args[i].id = i;
        pthread_create(&senior_threads[i], NULL, senior_doctor, &senior_args[i]);
    }
    for (int i = 0; i < NUM_JUNIOR; i++) {
        junior_args[i].id = i;
        pthread_create(&junior_threads[i], NULL, junior_doctor, &junior_args[i]);
    }

    pthread_create(&gen_thread, NULL, patient_generator, NULL);

    pthread_join(gen_thread, NULL);
    for (int i = 0; i < NUM_SENIOR; i++) pthread_join(senior_threads[i], NULL);
    for (int i = 0; i < NUM_JUNIOR; i++) pthread_join(junior_threads[i], NULL);
    pthread_join(promo_thread,   NULL);
    pthread_join(timeout_thread, NULL);

    printf("\n=== Simulation Complete: %d patients treated ===\n", total_treated);

    pthread_mutex_destroy(&queue_mutex);
    pthread_mutex_destroy(&stats_mutex);
    pthread_cond_destroy(&patient_cv);
    pthread_cond_destroy(&senior_cv);
    return 0;
}
